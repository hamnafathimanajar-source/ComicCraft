import os
import sys
from pathlib import Path

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from fastapi.testclient import TestClient
from app.main import app
from app.gemini_flash import generate_outline
from app.gemini_pro import generate_story
from app.image_generator import generate_image
from app.layout_builder import build_comic_layout
from app.exporters import save_pdf


def run_unit_tests():
    print("--- [1/6] Testing Outline Generation ---")
    outline = generate_outline(
        story_prompt="A brave fox exploring an enchanted forest.",
        character_name="Finn",
        setting="Enchanted Forest",
        tone="Adventure",
        art_style="Comic Book",
        allow_demo_fallback=True
    )
    assert len(outline) == 5, f"Expected 5 panels, got {len(outline)}"
    for idx, panel in enumerate(outline, start=1):
        assert panel["panel_number"] == idx
        assert "title" in panel and panel["title"]
        assert "scene_description" in panel and panel["scene_description"]
        assert "image_prompt" in panel and panel["image_prompt"]
    print("[OK] Outline generation test passed (5 panels verified).")

    print("\n--- [2/6] Testing Story & Dialogue Generation ---")
    story = generate_story(
        outline=outline,
        story_prompt="A brave fox exploring an enchanted forest.",
        character_name="Finn",
        setting="Enchanted Forest",
        tone="Adventure",
        allow_demo_fallback=True
    )
    assert len(story) == 5, f"Expected 5 story panels, got {len(story)}"
    for idx, s in enumerate(story, start=1):
        assert s["panel_number"] == idx
        assert "narration" in s and s["narration"]
        assert "dialogue" in s and s["dialogue"]
        assert "caption" in s
    print("[OK] Story & dialogue generation test passed.")

    print("\n--- [3/6] Testing Image Generation ---")
    img_path = generate_image(
        prompt=outline[0]["image_prompt"],
        panel_number=1,
        art_style="Comic Book",
        character_name="Finn",
        allow_demo_fallback=True
    )
    assert img_path.startswith("/static/panels/"), f"Unexpected image path: {img_path}"
    # Verify file exists on disk
    fs_img_path = PROJECT_ROOT / img_path.lstrip("/")
    assert fs_img_path.exists(), f"Image file not created at {fs_img_path}"
    assert fs_img_path.stat().st_size > 1000, "Image file is unexpectedly small"
    print(f"[OK] Image generation test passed: {img_path} ({fs_img_path.stat().st_size} bytes)")

    print("\n--- [4/6] Testing Layout Builder ---")
    images = [img_path] * 5
    layout = build_comic_layout(outline, story, images)
    assert len(layout) == 5, f"Expected 5 layout panels, got {len(layout)}"
    assert layout[0]["panel_number"] == 1
    assert layout[0]["title"] == outline[0]["title"]
    assert layout[0]["narration"] == story[0]["narration"]
    assert layout[0]["image_path"] == img_path
    print("[OK] Layout builder test passed.")

    print("\n--- [5/6] Testing PDF Exporter ---")
    pdf_path = save_pdf(
        comic_layout=layout,
        story_prompt="A brave fox exploring an enchanted forest.",
        character_name="Finn",
        setting="Enchanted Forest",
        tone="Adventure",
        art_style="Comic Book"
    )
    assert pdf_path.startswith("/static/exports/"), f"Unexpected PDF path: {pdf_path}"
    fs_pdf_path = PROJECT_ROOT / pdf_path.lstrip("/")
    assert fs_pdf_path.exists(), f"PDF file not created at {fs_pdf_path}"
    assert fs_pdf_path.stat().st_size > 5000, f"PDF file unexpectedly small: {fs_pdf_path.stat().st_size} bytes"
    print(f"[OK] PDF export test passed: {pdf_path} ({fs_pdf_path.stat().st_size} bytes)")

    print("\n--- [6/6] Testing FastAPI Routes via TestClient ---")
    client = TestClient(app)

    # 1. GET /
    res_index = client.get("/")
    assert res_index.status_code == 200, f"GET / returned {res_index.status_code}"
    assert "ComicCraft" in res_index.text
    print("[OK] GET / returned 200 OK with ComicCraft HTML.")

    # 2. GET /docs
    res_docs = client.get("/docs")
    assert res_docs.status_code == 200, f"GET /docs returned {res_docs.status_code}"
    print("[OK] GET /docs returned 200 OK.")

    # 3. GET /test-image
    res_test_img = client.get("/test-image?art_style=Comic%20Book&panel_number=1")
    assert res_test_img.status_code == 200, f"GET /test-image returned {res_test_img.status_code}"
    json_data = res_test_img.json()
    assert json_data["status"] == "success"
    print("[OK] GET /test-image returned 200 OK with image path.")

    # 4. POST /generate (Form submission)
    form_payload = {
        "story_prompt": "A brave fox exploring an enchanted forest finds a magic key.",
        "character_name": "Finn",
        "setting": "Enchanted Forest",
        "tone": "Adventure",
        "art_style": "Comic Book",
        "demo_mode": "true"
    }
    res_gen = client.post("/generate", data=form_payload)
    assert res_gen.status_code == 200, f"POST /generate failed with {res_gen.status_code}: {res_gen.text[:300]}"
    assert "Finn's Chronicle" in res_gen.text
    assert "PANEL 1 OF 5" in res_gen.text
    assert "Download Complete Comic (PDF)" in res_gen.text
    print("[OK] POST /generate returned 200 OK rendering comic_preview.html with all 5 panels.")

    # 5. POST /generate-comic/json (API endpoint)
    json_payload = {
        "story_prompt": "A heroic robot defending a neon city from rogue drones.",
        "character_name": "Spark",
        "setting": "City",
        "tone": "Adventure",
        "art_style": "Anime",
        "allow_demo_fallback": True
    }
    res_json_gen = client.post("/generate-comic/json", json=json_payload)
    assert res_json_gen.status_code == 200, f"POST /generate-comic/json returned {res_json_gen.status_code}"
    res_data = res_json_gen.json()
    assert res_data["status"] == "success"
    assert len(res_data["comic_layout"]) == 5
    assert "pdf_path" in res_data
    created_pdf = res_data["pdf_path"]
    print("[OK] POST /generate-comic/json returned 200 OK with 5 panels and PDF path.")

    # 6. GET /export-success
    res_export = client.get(f"/export-success?pdf_path={created_pdf}&character_name=Spark")
    assert res_export.status_code == 200
    assert "Your Comic Has Been Successfully Created!" in res_export.text
    assert "Spark" in res_export.text
    print("[OK] GET /export-success returned 200 OK.")

    # 7. Form validation test (empty character name should return 400 Bad Request)
    bad_payload = {
        "story_prompt": "Empty character test",
        "character_name": "   ",
        "setting": "Space",
        "tone": "Dramatic",
        "art_style": "Pixel Art",
    }
    res_bad = client.post("/generate", data=bad_payload)
    assert res_bad.status_code == 400
    assert "All fields are required" in res_bad.text
    print("[OK] Form validation error handling returned 400 Bad Request as expected.")

    print("\n==========================================")
    print("SUCCESS: ALL 6 TEST SUITES PASSED PERFECTLY!")
    print("==========================================")


if __name__ == "__main__":
    run_unit_tests()
