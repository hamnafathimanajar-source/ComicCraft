import os
import time
import uuid
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from fpdf import FPDF

logger = logging.getLogger(__name__)

STATIC_EXPORTS_DIR = Path(__file__).resolve().parent.parent / "static" / "exports"


def sanitize_text(text: str) -> str:
    """
    Sanitize text to prevent FPDF unicode encoding errors with standard fonts.
    Replaces common unicode punctuation with safe equivalents.
    """
    if not text:
        return ""
    replacements = {
        "\u2018": "'",
        "\u2019": "'",
        "\u201c": '"',
        "\u201d": '"',
        "\u2014": "--",
        "\u2013": "-",
        "\u2026": "...",
        "\u00a0": " ",
        "’": "'",
        "‘": "'",
        "“": '"',
        "”": '"',
        "—": "--",
        "–": "-",
        "…": "...",
        "•": "*",
    }
    for orig, rep in replacements.items():
        text = text.replace(orig, rep)
    # Ensure latin-1 / ascii compatibility for standard FPDF fonts
    return text.encode("latin-1", "replace").decode("latin-1")


class ComicPDF(FPDF):
    """Custom comic styled PDF document."""

    def __init__(self, story_title: str = "ComicCraft Story"):
        super().__init__(orientation="P", unit="mm", format="A4")
        self.story_title = sanitize_text(story_title)
        self.set_auto_page_break(auto=True, margin=15)

    def header(self):
        # Top decorative comic header bar on subsequent pages
        if self.page_no() > 1:
            self.set_fill_color(24, 24, 38)
            self.rect(0, 0, 210, 12, style="F")
            self.set_font("Helvetica", "B", 9)
            self.set_text_color(255, 215, 0)
            self.set_xy(10, 2)
            self.cell(100, 8, "COMICCRAFT  |  AI COMIC CREATOR", border=0, align="L")
            self.set_xy(110, 2)
            self.set_font("Helvetica", "I", 8)
            self.set_text_color(200, 200, 220)
            self.cell(90, 8, self.story_title[:45], border=0, align="R")
            self.ln(12)

    def footer(self):
        # Bottom page numbering
        self.set_y(-12)
        self.set_font("Helvetica", "B", 8)
        self.set_text_color(120, 120, 140)
        self.cell(0, 8, f"- Page {self.page_no()} -", border=0, align="C")


def save_pdf(
    comic_layout: List[Dict[str, Any]],
    story_prompt: str = "",
    character_name: str = "",
    setting: str = "",
    tone: str = "",
    art_style: str = ""
) -> str:
    """
    Generate and save a publication-ready comic book PDF.

    Args:
        comic_layout: 5-panel layout list.
        story_prompt: User's original prompt.
        character_name: Main character name.
        setting: Story setting.
        tone: Narrative tone.
        art_style: Illustration art style.

    Returns:
        Web-accessible relative URL path to the generated PDF (e.g., '/static/exports/comic_...pdf').
    """
    STATIC_EXPORTS_DIR.mkdir(parents=True, exist_ok=True)
    unique_id = uuid.uuid4().hex[:8]
    filename = f"comiccraft_{int(time.time())}_{unique_id}.pdf"
    output_path = STATIC_EXPORTS_DIR / filename
    web_path = f"/static/exports/{filename}"

    title = character_name if character_name else "Comic Story"
    pdf = ComicPDF(story_title=f"{title}'s Journey")

    # ================= PAGE 1: COVER PAGE =================
    pdf.add_page()
    # Dark cover background
    pdf.set_fill_color(17, 24, 39)
    pdf.rect(0, 0, 210, 297, style="F")

    # Comic Title Banner
    pdf.set_y(35)
    pdf.set_fill_color(239, 68, 68)
    pdf.rect(15, 30, 180, 26, style="F")
    pdf.set_draw_color(255, 255, 255)
    pdf.set_line_width(0.8)
    pdf.rect(17, 32, 176, 22, style="D")

    pdf.set_xy(15, 33)
    pdf.set_font("Helvetica", "B", 24)
    pdf.set_text_color(255, 255, 255)
    pdf.cell(180, 12, "COMICCRAFT CHRONICLES", border=0, align="C")

    pdf.set_xy(15, 45)
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(254, 240, 138)
    pdf.cell(180, 8, "AN AI-GENERATED 5-PANEL GRAPHIC STORY", border=0, align="C")

    # Story & Character Metadata Box
    pdf.set_y(70)
    pdf.set_fill_color(30, 41, 59)
    pdf.rect(20, 68, 170, 75, style="F")
    pdf.set_draw_color(245, 158, 11)
    pdf.set_line_width(1.0)
    pdf.rect(20, 68, 170, 75, style="D")

    pdf.set_xy(25, 74)
    pdf.set_font("Helvetica", "B", 13)
    pdf.set_text_color(245, 158, 11)
    pdf.cell(160, 8, "STORY SPECIFICATIONS", border=0, align="L")

    meta_items = [
        ("Protagonist:", character_name or "Hero"),
        ("Setting:", setting or "Everywhere"),
        ("Story Tone:", tone or "Adventure"),
        ("Art Style:", art_style or "Comic Book"),
    ]

    curr_y = 86
    for label, val in meta_items:
        pdf.set_xy(25, curr_y)
        pdf.set_font("Helvetica", "B", 10)
        pdf.set_text_color(203, 213, 225)
        pdf.cell(35, 6, label, border=0)
        pdf.set_font("Helvetica", "", 10)
        pdf.set_text_color(255, 255, 255)
        pdf.cell(125, 6, sanitize_text(val), border=0)
        curr_y += 8

    # Premise Box
    pdf.set_xy(25, curr_y + 2)
    pdf.set_font("Helvetica", "B", 10)
    pdf.set_text_color(203, 213, 225)
    pdf.cell(35, 6, "Premise:", border=0)
    pdf.set_xy(25, curr_y + 8)
    pdf.set_font("Helvetica", "I", 9)
    pdf.set_text_color(226, 232, 240)
    pdf.multi_cell(160, 5, sanitize_text(story_prompt or "An epic illustrated journey."))

    # Cover Image (Panel 1 Preview if available)
    if comic_layout and comic_layout[0].get("image_path"):
        first_img = comic_layout[0]["image_path"].lstrip("/")
        base_dir = Path(__file__).resolve().parent.parent
        img_fs_path = base_dir / first_img
        if img_fs_path.exists():
            try:
                # Place image on cover
                pdf.image(str(img_fs_path), x=35, y=155, w=140, h=105)
                # Outer border for image
                pdf.set_draw_color(255, 255, 255)
                pdf.set_line_width(1.2)
                pdf.rect(35, 155, 140, 105, style="D")
            except Exception as e:
                logger.warning(f"Could not draw cover preview image: {e}")

    # ================= 5 PANEL PAGES =================
    base_dir = Path(__file__).resolve().parent.parent

    for panel in comic_layout:
        pdf.add_page()
        pdf.set_fill_color(248, 250, 252)  # Clean light page background
        pdf.rect(0, 12, 210, 285, style="F")

        p_num = panel.get("panel_number", 1)
        p_title = sanitize_text(panel.get("title", f"Panel {p_num}"))
        p_caption = sanitize_text(panel.get("caption", ""))
        p_narration = sanitize_text(panel.get("narration", ""))
        p_dialogue = sanitize_text(panel.get("dialogue", ""))
        p_desc = sanitize_text(panel.get("scene_description", ""))

        # Panel Header Banner
        pdf.set_y(18)
        pdf.set_fill_color(220, 38, 38)
        pdf.rect(15, 16, 180, 14, style="F")
        pdf.set_draw_color(17, 24, 39)
        pdf.set_line_width(0.6)
        pdf.rect(15, 16, 180, 14, style="D")

        pdf.set_xy(18, 18)
        pdf.set_font("Helvetica", "B", 12)
        pdf.set_text_color(255, 255, 255)
        pdf.cell(174, 10, f"PANEL {p_num}: {p_title.upper()}", border=0, align="L")

        # Illustration Frame
        img_rel = panel.get("image_path", "").lstrip("/")
        img_abs = base_dir / img_rel
        img_w = 150
        img_h = 110
        img_x = (210 - img_w) / 2
        img_y = 35

        if img_abs.exists():
            try:
                pdf.image(str(img_abs), x=img_x, y=img_y, w=img_w, h=img_h)
                # Comic border
                pdf.set_draw_color(17, 24, 39)
                pdf.set_line_width(1.5)
                pdf.rect(img_x, img_y, img_w, img_h, style="D")
            except Exception as e:
                logger.error(f"Failed to embed image for panel {p_num}: {e}")
                pdf.set_xy(img_x, img_y + 40)
                pdf.set_font("Helvetica", "I", 11)
                pdf.set_text_color(100, 100, 100)
                pdf.cell(img_w, 10, "[Panel Illustration]", border=1, align="C")
        else:
            pdf.set_xy(img_x, img_y)
            pdf.set_fill_color(226, 232, 240)
            pdf.rect(img_x, img_y, img_w, img_h, style="FD")
            pdf.set_xy(img_x, img_y + 45)
            pdf.set_font("Helvetica", "B", 12)
            pdf.set_text_color(71, 85, 105)
            pdf.cell(img_w, 10, f"[Panel {p_num} Illustration]", border=0, align="C")

        # Comic Story Content Cards below Image
        curr_y = img_y + img_h + 8

        # 1. Caption Box (Comic yellow caption header)
        if p_caption:
            pdf.set_y(curr_y)
            pdf.set_fill_color(254, 240, 138)  # Yellow comic caption box
            caption_w = min(180, max(50, len(p_caption) * 3 + 12))
            pdf.rect(15, curr_y, caption_w, 7, style="FD")
            pdf.set_draw_color(0, 0, 0)
            pdf.set_line_width(0.4)
            pdf.set_xy(17, curr_y + 0.5)
            pdf.set_font("Helvetica", "B", 9)
            pdf.set_text_color(17, 24, 39)
            pdf.cell(caption_w - 4, 6, p_caption.upper(), border=0)
            curr_y += 10

        # 2. Narration Box (Classic comic narrator strip)
        if p_narration:
            pdf.set_y(curr_y)
            pdf.set_fill_color(241, 245, 249)
            pdf.set_draw_color(148, 163, 184)
            pdf.set_line_width(0.3)
            # Estimate height
            narr_text = f"NARRATOR: {p_narration}"
            pdf.set_font("Helvetica", "I", 9.5)
            pdf.set_text_color(30, 41, 59)
            pdf.set_xy(16, curr_y)
            pdf.multi_cell(178, 5.5, narr_text, border=1, fill=True)
            curr_y = pdf.get_y() + 4

        # 3. Speech Balloon / Dialogue Box
        if p_dialogue:
            pdf.set_y(curr_y)
            pdf.set_fill_color(255, 255, 255)
            pdf.set_draw_color(37, 99, 235)  # Blue dialogue outline
            pdf.set_line_width(0.8)
            pdf.set_xy(16, curr_y)
            pdf.set_font("Helvetica", "B", 10)
            pdf.set_text_color(15, 23, 42)
            pdf.multi_cell(178, 6, f'"{p_dialogue}"', border=1, fill=True)
            curr_y = pdf.get_y() + 4

        # 4. Scene Description Note (Subtle bottom visual description)
        if p_desc and curr_y < 265:
            pdf.set_y(curr_y)
            pdf.set_font("Helvetica", "", 8)
            pdf.set_text_color(100, 116, 139)
            pdf.set_xy(16, curr_y)
            pdf.multi_cell(178, 4.5, f"Scene: {p_desc}")

    # Save output
    pdf.output(str(output_path))
    logger.info(f"Successfully generated comic PDF at: {output_path}")
    return web_path
