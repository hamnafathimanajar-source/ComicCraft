import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)


def build_comic_layout(
    panels_outline: List[Dict[str, Any]],
    panels_story: List[Dict[str, Any]],
    image_paths: List[str]
) -> List[Dict[str, Any]]:
    """
    Match each generated panel image with its corresponding outline and story elements.

    Args:
        panels_outline: List of 5 panel outline dicts (title, scene_description, image_prompt).
        panels_story: List of 5 panel story dicts (narration, dialogue, caption).
        image_paths: List of 5 image paths corresponding to panels 1..5.

    Returns:
        Structured comic layout list containing 5 fully-assembled panel dicts.
    """
    comic_layout: List[Dict[str, Any]] = []

    for idx in range(1, 6):
        # 1. Outline match
        outline = next((p for p in panels_outline if p.get("panel_number") == idx), None)
        if not outline and idx - 1 < len(panels_outline):
            outline = panels_outline[idx - 1]
        outline = outline or {}

        # 2. Story match
        story = next((s for s in panels_story if s.get("panel_number") == idx), None)
        if not story and idx - 1 < len(panels_story):
            story = panels_story[idx - 1]
        story = story or {}

        # 3. Image match
        img_path = ""
        if idx - 1 < len(image_paths):
            img_path = image_paths[idx - 1]
        elif image_paths:
            img_path = image_paths[-1]

        title = outline.get("title", f"Panel {idx}")
        scene_desc = outline.get("scene_description", "")
        img_prompt = outline.get("image_prompt", "")

        narration = story.get("narration", "")
        dialogue = story.get("dialogue", "")
        caption = story.get("caption", f"PANEL {idx}")

        # Combined text representation for compact display or exports
        combined_text_parts = []
        if caption:
            combined_text_parts.append(f"[{caption}]")
        if narration:
            combined_text_parts.append(narration)
        if dialogue:
            combined_text_parts.append(dialogue)
        combined_text = "\n\n".join(combined_text_parts)

        panel_entry = {
            "panel_number": idx,
            "title": title,
            "scene_description": scene_desc,
            "image_prompt": img_prompt,
            "narration": narration,
            "dialogue": dialogue,
            "caption": caption,
            "image_path": img_path,
            "text": combined_text
        }

        comic_layout.append(panel_entry)

    logger.info(f"Built structured comic layout with {len(comic_layout)} panels.")
    return comic_layout
