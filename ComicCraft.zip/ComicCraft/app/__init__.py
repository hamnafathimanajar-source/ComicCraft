"""ComicCraft Package Initialization."""

__version__ = "1.0.0"
