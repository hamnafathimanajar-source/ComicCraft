import os
import json
import logging
from typing import List, Dict, Any
from dotenv import load_dotenv

load_dotenv()

logger = logging.getLogger(__name__)

FLASH_MODEL_NAME = os.getenv("GEMINI_FLASH_MODEL", "gemini-1.5-flash")


def generate_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str,
    allow_demo_fallback: bool = False
) -> List[Dict[str, Any]]:
    """
    Generate a structured 5-panel comic outline using Google Gemini Flash.

    Args:
        story_prompt: The core idea or narrative seed.
        character_name: The name of the primary protagonist.
        setting: The comic's world or environment.
        tone: Emotional tone or narrative style.
        art_style: Visual art style for image prompts.
        allow_demo_fallback: If True and GEMINI_API_KEY is missing, returns demo data.

    Returns:
        A list of exactly 5 dictionaries, each containing:
            - panel_number (int)
            - title (str)
            - scene_description (str)
            - image_prompt (str)
    """
    api_key = os.getenv("GEMINI_API_KEY", "").strip()

    if not api_key:
        if allow_demo_fallback:
            logger.warning("GEMINI_API_KEY not found. Using local demo outline fallback.")
            return _generate_demo_outline(story_prompt, character_name, setting, tone, art_style)
        raise ValueError(
            "GEMINI_API_KEY is missing. Please set your GEMINI_API_KEY in the .env file or environment variables."
        )

    try:
        import google.generativeai as genai
    except ImportError:
        raise ImportError(
            "The google-generativeai package is required. Install it using 'pip install google-generativeai'."
        )

    genai.configure(api_key=api_key)

    system_instruction = (
        "You are an expert comic book creator and visual storyboard artist. "
        "Your task is to generate a structured 5-panel comic outline based on user inputs. "
        "You MUST return a valid JSON array containing EXACTLY 5 panel objects. "
        "Do not include any Markdown code block formatting or explanation outside the JSON. "
        "Each panel object must have the exact keys: 'panel_number', 'title', 'scene_description', and 'image_prompt'."
    )

    user_prompt = f"""
Create a 5-panel comic outline with the following specifications:
- Story Prompt: {story_prompt}
- Main Character: {character_name}
- Setting: {setting}
- Tone: {tone}
- Art Style: {art_style}

Requirements:
1. Exactly 5 sequential panels following a classic comic arc (Introduction, Inciting Incident, Rising Action, Climax, Resolution).
2. Each panel must have:
   - "panel_number": Integer (1 to 5)
   - "title": Short punchy panel title
   - "scene_description": Vivid description of the action and composition
   - "image_prompt": Detailed visual prompt for an image generator (incorporate '{art_style}' style, '{character_name}', visual atmosphere, camera angle, and comic illustration aesthetics).

Respond ONLY with a valid JSON array of 5 panel objects:
[
  {{
    "panel_number": 1,
    "title": "Panel Title",
    "scene_description": "Description of scene...",
    "image_prompt": "Comic book illustration in {art_style} style showing..."
  }},
  ...
]
"""

    model = genai.GenerativeModel(
        model_name=FLASH_MODEL_NAME,
        system_instruction=system_instruction
    )

    response = model.generate_content(
        user_prompt,
        generation_config={
            "response_mime_type": "application/json",
            "temperature": 0.7,
        }
    )

    response_text = response.text.strip() if response and response.text else ""
    if not response_text:
        raise RuntimeError("Received empty response from Gemini Flash model.")

    # Clean markdown code blocks if present
    if response_text.startswith("```"):
        lines = response_text.splitlines()
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].startswith("```"):
            lines = lines[:-1]
        response_text = "\n".join(lines).strip()

    try:
        parsed_data = json.loads(response_text)
    except json.JSONDecodeError as err:
        logger.error(f"Failed to parse Gemini Flash JSON: {response_text}")
        raise ValueError(f"Gemini Flash output was not valid JSON: {err}")

    # Handle wrapper object if Gemini returned {"panels": [...]}
    if isinstance(parsed_data, dict):
        for key in ["panels", "comic", "outline", "data"]:
            if key in parsed_data and isinstance(parsed_data[key], list):
                parsed_data = parsed_data[key]
                break

    if not isinstance(parsed_data, list):
        raise ValueError("Gemini Flash output must be a list of panel dictionaries.")

    # Validate and normalize to exactly 5 panels
    normalized_panels: List[Dict[str, Any]] = []
    for idx, panel in enumerate(parsed_data[:5], start=1):
        if not isinstance(panel, dict):
            continue
        normalized_panels.append({
            "panel_number": idx,
            "title": str(panel.get("title", f"Panel {idx}")).strip(),
            "scene_description": str(panel.get("scene_description", "Comic scene description")).strip(),
            "image_prompt": str(panel.get("image_prompt", f"{art_style} style comic panel of {character_name} in {setting}")).strip()
        })

    # If fewer than 5 panels, pad up to 5
    while len(normalized_panels) < 5:
        idx = len(normalized_panels) + 1
        normalized_panels.append({
            "panel_number": idx,
            "title": f"Panel {idx}: Story Continues",
            "scene_description": f"{character_name} faces an unexpected turn in {setting}.",
            "image_prompt": f"Vibrant comic illustration in {art_style} style of {character_name} in {setting}, panel {idx} cinematic composition."
        })

    return normalized_panels[:5]


def _generate_demo_outline(
    story_prompt: str,
    character_name: str,
    setting: str,
    tone: str,
    art_style: str
) -> List[Dict[str, Any]]:
    """Local fallback outline for offline testing and demo verification."""
    return [
        {
            "panel_number": 1,
            "title": f"1. The Awakening in {setting}",
            "scene_description": f"{character_name} stands watchful at the entrance of {setting}, scanning the landscape with determination.",
            "image_prompt": f"Dynamic comic illustration, {art_style} art style. {character_name} standing heroic in {setting}, establishing wide shot, vibrant colors, comic book line art."
        },
        {
            "panel_number": 2,
            "title": "2. The Hidden Discovery",
            "scene_description": f"{character_name} notices an unusual glimmer through the terrain, revealing an ancient secret.",
            "image_prompt": f"Dramatic {art_style} comic panel. Close-up of {character_name} looking surprised, glowing mysterious relic in foreground, {setting} background, high contrast lighting."
        },
        {
            "panel_number": 3,
            "title": "3. Rising Danger",
            "scene_description": f"The environment shifts abruptly as an unexpected obstacle challenges {character_name}.",
            "image_prompt": f"Action comic shot, {art_style} style. {character_name} dodging an obstacle in {setting}, dynamic motion lines, energetic {tone} atmosphere."
        },
        {
            "panel_number": 4,
            "title": "4. The Defining Moment",
            "scene_description": f"Gathering courage, {character_name} makes a daring move to overcome the central challenge.",
            "image_prompt": f"Climactic superhero comic composition, {art_style} style. {character_name} leaping forward in decisive action, vivid lighting, dramatic angle in {setting}."
        },
        {
            "panel_number": 5,
            "title": "5. A New Horizon",
            "scene_description": f"{character_name} catches their breath as peace returns, ready for the next adventure.",
            "image_prompt": f"{art_style} art style comic panel. {character_name} looking towards a majestic horizon over {setting}, warm victorious lighting, triumphant {tone} mood."
        }
    ]
