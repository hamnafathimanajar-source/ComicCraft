import os
import io
import time
import uuid
import logging
from typing import Optional
from pathlib import Path
from dotenv import load_dotenv
import requests
from PIL import Image, ImageDraw, ImageFont

load_dotenv()

logger = logging.getLogger(__name__)

SD_MODEL_ID = os.getenv("SD_MODEL_ID", "runwayml/stable-diffusion-v1-5")
HF_API_KEY = os.getenv("HF_API_KEY", "").strip()

# Base directory for storing panels
STATIC_PANELS_DIR = Path(__file__).resolve().parent.parent / "static" / "panels"


def generate_image(
    prompt: str,
    panel_number: int,
    art_style: str = "Comic Book",
    character_name: str = "",
    allow_demo_fallback: bool = False
) -> str:
    """
    Generate a comic-style illustration from each panel's image prompt using
    Hugging Face Stable Diffusion / Diffusers.

    Args:
        prompt: Detailed visual prompt for this panel.
        panel_number: Panel index (1 to 5).
        art_style: Chosen art style (Comic Book, Anime, etc.).
        character_name: Character name for visual context.
        allow_demo_fallback: Whether to generate a comic stylized placeholder
                             if HF_API_KEY is not configured or fails.

    Returns:
        Web-accessible relative URL path to the saved image (e.g., '/static/panels/panel_1_abc123.png').
    """
    STATIC_PANELS_DIR.mkdir(parents=True, exist_ok=True)
    safe_token = uuid.uuid4().hex[:8]
    filename = f"panel_{panel_number}_{int(time.time())}_{safe_token}.png"
    output_path = STATIC_PANELS_DIR / filename
    web_path = f"/static/panels/{filename}"

    hf_key = os.getenv("HF_API_KEY", "").strip()

    # Enhance the prompt with comic aesthetics
    enhanced_prompt = f"{prompt}, {art_style} style, comic book panel, high quality, vibrant illustration, dynamic composition"

    if hf_key:
        try:
            logger.info(f"Generating panel {panel_number} with Stable Diffusion ({SD_MODEL_ID})...")
            image_data = _call_hf_inference_api(enhanced_prompt, hf_key, SD_MODEL_ID)
            if image_data:
                # Open with PIL to verify integrity and save as PNG
                img = Image.open(io.BytesIO(image_data))
                img = _add_comic_panel_border(img, panel_number, art_style)
                img.save(output_path, format="PNG")
                logger.info(f"Successfully generated panel {panel_number} via Stable Diffusion: {output_path}")
                return web_path
        except Exception as e:
            logger.error(f"Hugging Face Stable Diffusion generation failed for panel {panel_number}: {e}")
            if not allow_demo_fallback:
                raise RuntimeError(
                    f"Hugging Face Stable Diffusion generation failed: {e}. "
                    "Check your HF_API_KEY and model availability, or enable demo mode."
                )

    # If no HF_API_KEY or if demo fallback is permitted:
    if allow_demo_fallback or not hf_key:
        if not hf_key and not allow_demo_fallback:
            raise ValueError(
                "HF_API_KEY is missing. Please set your HF_API_KEY in the .env file or enable offline preview."
            )

        logger.info(f"Creating comic-styled visual panel {panel_number} (offline/fallback mode)...")
        img = _create_stylized_comic_panel(panel_number, art_style, character_name, prompt)
        img.save(output_path, format="PNG")
        return web_path

    raise RuntimeError(f"Could not generate image for panel {panel_number}.")


def _call_hf_inference_api(prompt: str, api_key: str, model_id: str) -> Optional[bytes]:
    """Call Hugging Face Serverless Inference API for Stable Diffusion."""
    endpoints = [
        f"https://api-inference.huggingface.co/models/{model_id}",
        f"https://router.huggingface.co/hf-inference/models/{model_id}",
    ]

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "x-use-cache": "false"
    }

    payload = {
        "inputs": prompt,
        "parameters": {
            "negative_prompt": "blurry, low quality, deformed, distorted, extra limbs, bad anatomy, text, watermark, bad proportions",
            "guidance_scale": 7.5,
            "num_inference_steps": 30,
            "width": 512,
            "height": 512
        }
    }

    last_error = None
    for url in endpoints:
        try:
            # Poll up to 3 times in case model is loading (503)
            for attempt in range(3):
                response = requests.post(url, headers=headers, json=payload, timeout=45)
                if response.status_code == 200:
                    content_type = response.headers.get("content-type", "")
                    if "image" in content_type or response.content[:8] in [b"\x89PNG\r\n\x1a\n", b"\xff\xd8\xff"]:
                        return response.content
                    elif "json" in content_type:
                        # might be JSON error
                        res_json = response.json()
                        raise RuntimeError(f"Hugging Face returned JSON: {res_json}")
                elif response.status_code == 503:
                    # Model loading, wait specified time or 10s
                    try:
                        info = response.json()
                        wait_sec = min(int(info.get("estimated_time", 10)), 15)
                    except Exception:
                        wait_sec = 8
                    logger.info(f"Model {model_id} loading. Waiting {wait_sec}s (attempt {attempt + 1}/3)...")
                    time.sleep(wait_sec)
                else:
                    last_error = f"HTTP {response.status_code}: {response.text[:200]}"
                    break
        except requests.RequestException as e:
            last_error = str(e)
            continue

    if last_error:
        raise RuntimeError(f"HF Inference API error: {last_error}")
    return None


def _add_comic_panel_border(img: Image.Image, panel_number: int, art_style: str) -> Image.Image:
    """Adds a bold comic-book frame border and panel badge to an image."""
    img = img.convert("RGBA")
    w, h = img.size

    # Create overlay for border and badge
    overlay = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)

    border_thickness = 8
    # Outer dark comic border
    draw.rectangle([0, 0, w - 1, h - 1], outline=(20, 20, 30, 255), width=border_thickness)
    # Inner white/golden pinstripe
    draw.rectangle([border_thickness, border_thickness, w - border_thickness - 1, h - border_thickness - 1],
                   outline=(255, 230, 100, 200), width=2)

    # Panel Badge in Top Left
    badge_w, badge_h = 100, 32
    draw.polygon(
        [
            (border_thickness, border_thickness),
            (border_thickness + badge_w, border_thickness),
            (border_thickness + badge_w - 12, border_thickness + badge_h),
            (border_thickness, border_thickness + badge_h)
        ],
        fill=(220, 38, 38, 240),
        outline=(20, 20, 30, 255)
    )

    badge_text = f"PANEL {panel_number}"
    draw.text((border_thickness + 12, border_thickness + 8), badge_text, fill=(255, 255, 255, 255))

    return Image.alpha_composite(img, overlay).convert("RGB")


def _create_stylized_comic_panel(
    panel_number: int,
    art_style: str,
    character_name: str,
    prompt: str
) -> Image.Image:
    """
    Creates an aesthetically pleasing comic panel illustration card
    used for offline preview, demonstration, or when HF_API_KEY is not configured.
    """
    width, height = 640, 480
    img = Image.new("RGB", (width, height), color=(18, 20, 32))
    draw = ImageDraw.Draw(img)

    # Dynamic color themes based on art style & panel number
    palette = {
        "Comic Book": [(239, 68, 68), (37, 99, 235), (245, 158, 11)],
        "Anime": [(236, 72, 153), (139, 92, 246), (59, 130, 246)],
        "Pixel Art": [(16, 185, 129), (6, 182, 212), (99, 102, 241)],
        "Realistic": [(75, 85, 99), (30, 41, 59), (120, 53, 15)],
    }.get(art_style, [(99, 102, 241), (168, 85, 247), (236, 72, 153)])

    theme_color = palette[(panel_number - 1) % len(palette)]
    base_color = (25, 28, 44)

    # Draw vertical/diagonal gradient stripes for comic background
    for y in range(0, height, 4):
        ratio = y / height
        r = int(base_color[0] * (1 - ratio * 0.6) + theme_color[0] * (ratio * 0.4))
        g = int(base_color[1] * (1 - ratio * 0.6) + theme_color[1] * (ratio * 0.4))
        b = int(base_color[2] * (1 - ratio * 0.6) + theme_color[2] * (ratio * 0.4))
        draw.line([(0, y), (width, y)], fill=(r, g, b), width=4)

    # Stylized comic action burst or rays in center
    center_x, center_y = width // 2, height // 2 - 20
    import math
    num_rays = 16
    for i in range(num_rays):
        angle = (i * 2 * math.pi) / num_rays
        end_x = center_x + int(math.cos(angle) * 360)
        end_y = center_y + int(math.sin(angle) * 360)
        draw.polygon(
            [
                (center_x, center_y),
                (center_x + int(math.cos(angle + 0.1) * 360), center_y + int(math.sin(angle + 0.1) * 360)),
                (end_x, end_y)
            ],
            fill=(theme_color[0], theme_color[1], theme_color[2])
        )

    # Dim center overlay
    draw.ellipse([center_x - 140, center_y - 120, center_x + 140, center_y + 120], fill=(15, 18, 30))

    # Center Comic Symbol / Vignette
    draw.ellipse([center_x - 90, center_y - 90, center_x + 90, center_y + 90], outline=theme_color, width=4)
    draw.polygon(
        [
            (center_x, center_y - 50),
            (center_x + 45, center_y + 40),
            (center_x, center_y + 20),
            (center_x - 45, center_y + 40)
        ],
        fill=(255, 230, 100),
        outline=(20, 20, 30)
    )

    # Stylized banner card for prompt description
    card_margin = 24
    card_bottom = height - 24
    card_top = card_bottom - 110
    draw.rounded_rectangle(
        [card_margin, card_top, width - card_margin, card_bottom],
        radius=12,
        fill=(10, 12, 22),
        outline=(255, 255, 255),
        width=2
    )

    # Text wrapping helper
    def wrap_text(text: str, max_chars: int = 58) -> list:
        words = text.split()
        lines = []
        cur = []
        for w in words:
            if sum(len(x) for x in cur) + len(cur) + len(w) <= max_chars:
                cur.append(w)
            else:
                lines.append(" ".join(cur))
                cur = [w]
        if cur:
            lines.append(" ".join(cur))
        return lines

    # Write scene prompt summary
    draw.text((card_margin + 16, card_top + 10), f"ART STYLE: {art_style.upper()} | PANEL #{panel_number}", fill=(255, 215, 0))
    prompt_lines = wrap_text(f"Prompt: {prompt}", max_chars=60)
    line_y = card_top + 32
    for line in prompt_lines[:2]:
        draw.text((card_margin + 16, line_y), line, fill=(220, 225, 240))
        line_y += 18

    # Top panel badge
    badge_poly = [(16, 16), (130, 16), (115, 52), (16, 52)]
    draw.polygon(badge_poly, fill=(239, 68, 68), outline=(255, 255, 255))
    draw.text((28, 26), f"PANEL {panel_number}/5", fill=(255, 255, 255))

    # Top right art style badge
    style_text = f"STYLE: {art_style}"
    draw.rounded_rectangle([width - 170, 16, width - 16, 48], radius=6, fill=(30, 41, 59), outline=(148, 163, 184))
    draw.text((width - 155, 24), style_text, fill=(241, 245, 249))

    # Outer comic border
    draw.rectangle([0, 0, width - 1, height - 1], outline=(0, 0, 0), width=10)
    draw.rectangle([10, 10, width - 11, height - 11], outline=(255, 255, 255), width=2)

    return img
