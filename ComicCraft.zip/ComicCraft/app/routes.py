import os
import logging
from typing import Optional, List, Dict, Any
from pathlib import Path
from fastapi import APIRouter, Request, Form, HTTPException, status
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field, field_validator

from .gemini_flash import generate_outline
from .gemini_pro import generate_story
from .image_generator import generate_image
from .layout_builder import build_comic_layout
from .exporters import save_pdf

logger = logging.getLogger(__name__)

router = APIRouter()

TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"
templates = Jinja2Templates(directory=str(TEMPLATES_DIR))


class PromptRequest(BaseModel):
    """Pydantic model for comic generation API requests."""
    story_prompt: str = Field(..., description="Core narrative premise of the comic story")
    character_name: str = Field(..., description="Name of the main character")
    setting: str = Field(..., description="Story setting or world")
    tone: str = Field(..., description="Story tone (e.g., Adventure, Funny, Dramatic)")
    art_style: str = Field(..., description="Visual art style for illustrations")
    allow_demo_fallback: Optional[bool] = Field(
        default=False,
        description="Whether to permit offline demo fallback if API keys are missing"
    )

    @field_validator("story_prompt", "character_name", "setting", "tone", "art_style")
    @classmethod
    def validate_non_empty(cls, value: str, info) -> str:
        if not value or not value.strip():
            raise ValueError(f"Field '{info.field_name}' cannot be empty.")
        return value.strip()


def check_api_keys() -> Dict[str, bool]:
    """Check availability of required environment variables."""
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    hf_key = os.getenv("HF_API_KEY", "").strip()
    return {
        "has_gemini": bool(gemini_key),
        "has_hf": bool(hf_key),
    }


@router.get("/", response_class=HTMLResponse)
async def get_index(request: Request):
    """Render the ComicCraft creator homepage."""
    key_status = check_api_keys()
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={
            "has_gemini": key_status["has_gemini"],
            "has_hf": key_status["has_hf"],
            "error": None,
            "form_data": {}
        }
    )


@router.post("/generate", response_class=HTMLResponse)
async def generate_comic_form(
    request: Request,
    story_prompt: str = Form(...),
    character_name: str = Form(...),
    setting: str = Form(...),
    custom_setting: Optional[str] = Form(None),
    tone: str = Form(...),
    custom_tone: Optional[str] = Form(None),
    art_style: str = Form(...),
    custom_art_style: Optional[str] = Form(None),
    demo_mode: Optional[str] = Form(None)
):
    """
    Handle web form submission to generate a complete 5-panel comic story and PDF.
    """
    # Resolve custom choices if selected
    resolved_setting = custom_setting.strip() if setting == "Custom" and custom_setting else setting.strip()
    resolved_tone = custom_tone.strip() if tone == "Custom" and custom_tone else tone.strip()
    resolved_art_style = custom_art_style.strip() if art_style == "Custom" and custom_art_style else art_style.strip()

    form_data = {
        "story_prompt": story_prompt.strip(),
        "character_name": character_name.strip(),
        "setting": setting,
        "custom_setting": custom_setting or "",
        "tone": tone,
        "custom_tone": custom_tone or "",
        "art_style": art_style,
        "custom_art_style": custom_art_style or "",
    }

    key_status = check_api_keys()
    is_demo = (demo_mode == "true" or demo_mode == "on" or not key_status["has_gemini"])

    # Validation: empty field checks
    if not story_prompt.strip() or not character_name.strip() or not resolved_setting or not resolved_tone or not resolved_art_style:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={
                "has_gemini": key_status["has_gemini"],
                "has_hf": key_status["has_hf"],
                "error": "All fields are required. Please fill in story prompt, character name, setting, tone, and art style.",
                "form_data": form_data
            },
            status_code=status.HTTP_400_BAD_REQUEST
        )

    # If Gemini API key is missing and demo mode wasn't explicitly selected:
    if not key_status["has_gemini"] and not is_demo:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={
                "has_gemini": False,
                "has_hf": key_status["has_hf"],
                "error": "GEMINI_API_KEY environment variable is not configured. Please add it to your .env file or check the 'Enable Offline Demo' toggle to test the full pipeline.",
                "form_data": form_data
            },
            status_code=status.HTTP_400_BAD_REQUEST
        )

    try:
        logger.info(f"Starting comic generation for '{character_name}' (Demo Mode: {is_demo})...")

        # 1. Gemini Flash -> 5-panel outline
        outline = generate_outline(
            story_prompt=story_prompt.strip(),
            character_name=character_name.strip(),
            setting=resolved_setting,
            tone=resolved_tone,
            art_style=resolved_art_style,
            allow_demo_fallback=is_demo
        )

        # 2. Gemini Pro -> detailed story & dialogue
        story = generate_story(
            outline=outline,
            story_prompt=story_prompt.strip(),
            character_name=character_name.strip(),
            setting=resolved_setting,
            tone=resolved_tone,
            allow_demo_fallback=is_demo
        )

        # 3. Stable Diffusion / Hugging Face -> 5 comic panel illustrations
        image_paths = []
        for panel in outline:
            p_num = panel.get("panel_number", len(image_paths) + 1)
            p_prompt = panel.get("image_prompt", f"{resolved_art_style} scene of {character_name}")
            img_path = generate_image(
                prompt=p_prompt,
                panel_number=p_num,
                art_style=resolved_art_style,
                character_name=character_name.strip(),
                allow_demo_fallback=True  # allows graceful fallback if HF_API_KEY is unset or encounters rate limits
            )
            image_paths.append(img_path)

        # 4. Layout Builder -> Match panels, text, and images
        comic_layout = build_comic_layout(outline, story, image_paths)

        # 5. PDF Export
        pdf_path = save_pdf(
            comic_layout=comic_layout,
            story_prompt=story_prompt.strip(),
            character_name=character_name.strip(),
            setting=resolved_setting,
            tone=resolved_tone,
            art_style=resolved_art_style
        )

        # 6. Render preview
        return templates.TemplateResponse(
            request=request,
            name="comic_preview.html",
            context={
                "comic_layout": comic_layout,
                "story_prompt": story_prompt.strip(),
                "character_name": character_name.strip(),
                "setting": resolved_setting,
                "tone": resolved_tone,
                "art_style": resolved_art_style,
                "pdf_path": pdf_path,
                "is_demo": is_demo
            }
        )

    except Exception as exc:
        logger.exception("Comic generation failed unexpectedly:")
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={
                "has_gemini": key_status["has_gemini"],
                "has_hf": key_status["has_hf"],
                "error": f"Generation Error: {str(exc)}",
                "form_data": form_data
            },
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR
        )


@router.post("/generate-comic/json")
async def generate_comic_json(req: PromptRequest):
    """
    JSON API endpoint for programmatic comic generation.
    Accepts PromptRequest and returns structured comic layout and PDF path.
    """
    key_status = check_api_keys()
    allow_demo = req.allow_demo_fallback or (not key_status["has_gemini"])

    if not key_status["has_gemini"] and not allow_demo:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="GEMINI_API_KEY environment variable is missing. Configure it in .env or set allow_demo_fallback: true."
        )

    try:
        # Step 1: Outline
        outline = generate_outline(
            story_prompt=req.story_prompt,
            character_name=req.character_name,
            setting=req.setting,
            tone=req.tone,
            art_style=req.art_style,
            allow_demo_fallback=allow_demo
        )

        # Step 2: Story
        story = generate_story(
            outline=outline,
            story_prompt=req.story_prompt,
            character_name=req.character_name,
            setting=req.setting,
            tone=req.tone,
            allow_demo_fallback=allow_demo
        )

        # Step 3: Images
        image_paths = []
        for panel in outline:
            p_num = panel.get("panel_number", len(image_paths) + 1)
            p_prompt = panel.get("image_prompt", "")
            img_path = generate_image(
                prompt=p_prompt,
                panel_number=p_num,
                art_style=req.art_style,
                character_name=req.character_name,
                allow_demo_fallback=True
            )
            image_paths.append(img_path)

        # Step 4: Layout
        comic_layout = build_comic_layout(outline, story, image_paths)

        # Step 5: PDF
        pdf_path = save_pdf(
            comic_layout=comic_layout,
            story_prompt=req.story_prompt,
            character_name=req.character_name,
            setting=req.setting,
            tone=req.tone,
            art_style=req.art_style
        )

        return JSONResponse(
            status_code=status.HTTP_200_OK,
            content={
                "status": "success",
                "character_name": req.character_name,
                "story_prompt": req.story_prompt,
                "setting": req.setting,
                "tone": req.tone,
                "art_style": req.art_style,
                "pdf_path": pdf_path,
                "demo_mode": allow_demo,
                "comic_layout": comic_layout
            }
        )
    except Exception as exc:
        logger.exception("JSON Comic generation error:")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Comic generation failed: {str(exc)}"
        )


@router.get("/export-success", response_class=HTMLResponse)
async def export_success(
    request: Request,
    pdf_path: str = "/static/exports/comic.pdf",
    character_name: str = "Hero"
):
    """Display the download and completion page."""
    # Verify that the PDF actually exists on disk before claiming success
    clean_rel_path = pdf_path.lstrip("/")
    base_dir = Path(__file__).resolve().parent.parent
    file_exists = (base_dir / clean_rel_path).exists()

    return templates.TemplateResponse(
        request=request,
        name="export_success.html",
        context={
            "pdf_path": pdf_path,
            "character_name": character_name,
            "file_exists": file_exists
        }
    )


@router.get("/test-image")
async def test_image(
    prompt: str = "A brave fox exploring an enchanted glowing forest, comic book illustration",
    art_style: str = "Comic Book",
    panel_number: int = 1
):
    """
    Developer route to test image generation independently.
    """
    try:
        img_path = generate_image(
            prompt=prompt,
            panel_number=panel_number,
            art_style=art_style,
            character_name="Test Character",
            allow_demo_fallback=True
        )
        return {
            "status": "success",
            "panel_number": panel_number,
            "art_style": art_style,
            "image_path": img_path,
            "test_url": f"http://127.0.0.1:8000{img_path}"
        }
    except Exception as exc:
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={"status": "error", "message": str(exc)}
        )
